package com.capstone.educollab1.ui.schedule

class Schedule {
}