package com.capstone.educollab1.ui.schedule

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.capstone.educollab1.databinding.ItemInsideScheduleBinding
import com.capstone.educollab1.ui.remote.ScheduleResponse

class InsideScheduleAdapter(
    private val onEditClick: (ScheduleResponse) -> Unit,
    private val onDeleteClick: (ScheduleResponse) -> Unit
) : ListAdapter<ScheduleResponse, InsideScheduleAdapter.InsideScheduleViewHolder>(ScheduleDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InsideScheduleViewHolder {
        val binding = ItemInsideScheduleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return InsideScheduleViewHolder(binding)
    }

    override fun onBindViewHolder(holder: InsideScheduleViewHolder, position: Int) {
        val schedule = getItem(position)
        holder.bind(schedule)
    }

    // ViewHolder for each individual schedule item
    inner class InsideScheduleViewHolder(private val binding: ItemInsideScheduleBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(schedule: ScheduleResponse) {
            binding.subjectNameText.text = schedule.subject
            binding.timeRangeText.text = schedule.period

            binding.editButton.setOnClickListener {
                onEditClick(schedule)
            }

            binding.deleteButton.setOnClickListener {
                onDeleteClick(schedule)
            }
        }
    }

    class ScheduleDiffCallback : DiffUtil.ItemCallback<ScheduleResponse>() {
        override fun areItemsTheSame(oldItem: ScheduleResponse, newItem: ScheduleResponse): Boolean {
            return oldItem.scheduleId == newItem.scheduleId
        }

        override fun areContentsTheSame(oldItem: ScheduleResponse, newItem: ScheduleResponse): Boolean {
            return oldItem == newItem
        }
    }
}
