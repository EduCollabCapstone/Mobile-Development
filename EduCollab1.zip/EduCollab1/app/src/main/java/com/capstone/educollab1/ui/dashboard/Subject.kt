package com.capstone.educollab1.ui.dashboard

data class Subject(
    val name: String,
    var score: Int
)
