package com.capstone.educollab1.customview

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.text.method.PasswordTransformationMethod
import android.util.AttributeSet
import android.view.MotionEvent
import androidx.appcompat.widget.AppCompatEditText
import androidx.core.content.ContextCompat
import com.capstone.educollab1.R

@SuppressLint("ClickableViewAccessibility")
class CustomPasswordEditText @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = android.R.attr.editTextStyle
) : AppCompatEditText(context, attrs, defStyleAttr) {

    private var isPasswordVisible = false
    private var isError: Boolean = false
    private var eyeIcon: Drawable? = null

    init {
        eyeIcon = ContextCompat.getDrawable(context, R.drawable.ic_eye)

        transformationMethod = PasswordTransformationMethod.getInstance()

        // Apply default padding
        setPadding(16, 16, 48, 16) // Increased right padding for icon

        updatePasswordVisibilityIcon()

        // Add text watcher to validate input
        addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                validatePassword(s.toString())
            }

            override fun afterTextChanged(s: Editable?) {
                validatePassword(s.toString())
            }
        })

        // Set touch listener for password visibility toggle
        setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_UP) {
                val drawableEnd = compoundDrawablesRelative[2]
                if (drawableEnd != null && event.x >= (width - paddingRight - drawableEnd.bounds.width())) {
                    togglePasswordVisibility()
                    return@setOnTouchListener true
                }
            }
            false
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
    }

    private fun togglePasswordVisibility() {
        isPasswordVisible = !isPasswordVisible
        transformationMethod = if (isPasswordVisible) null else PasswordTransformationMethod.getInstance()
        updatePasswordVisibilityIcon()
        setSelection(text?.length ?: 0) // Keep cursor at the end
    }

    private fun updatePasswordVisibilityIcon() {
        eyeIcon?.setBounds(0, 0, 40, 40) // Set icon size
        setCompoundDrawablesRelative(null, null, eyeIcon, null)
    }

    private fun validatePassword(input: String) {
        // Validate password length
        isError = if (input.length < 8) {
            error = context.getString(R.string.password_length) // Error string must exist in resources
            true
        } else {
            error = null
            false
        }
    }
}
